import{w as l}from"./B-GMrp1z.js";const n=l({username:null,publickey:null,location:null}),e=l({username:null,publickey:null,location:null});export{e as a,n as u};
