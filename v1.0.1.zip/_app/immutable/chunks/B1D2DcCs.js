function r(n,s,l){var t=n==null?"":""+n;return t===""?null:t}function a(n,s){return n==null?null:String(n)}export{a,r as t};
