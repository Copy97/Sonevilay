import{w as e}from"./B-GMrp1z.js";const r=typeof window<"u"&&window.matchMedia("(prefers-color-scheme: dark)").matches,a=e(r);export{a as d};
