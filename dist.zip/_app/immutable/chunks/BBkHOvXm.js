import{w as l}from"./B-GMrp1z.js";const e=l({image:null,result:null});export{e as r};
